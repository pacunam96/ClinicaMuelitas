package com.dh.clase23.repository;

import com.dh.clase23.model.Odontologo;
import org.springframework.data.jpa.repository.JpaRepository;

public interface OdontologoRepository extends JpaRepository<Odontologo,Long> {
}
