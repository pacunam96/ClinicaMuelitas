package com.dh.clase23.dao;

import com.dh.clase23.model.Turno;

import java.util.ArrayList;
import java.util.List;

public class TurnoDAOLista implements IDao<Turno> {
    private List<Turno> turnosBD=new ArrayList<>();
    @Override
    public Turno guardar(Turno turno) {
        turnosBD.add(turno);
        return turno;
    }

    @Override
    public Turno buscar(Integer id) {
        for (Turno turno:turnosBD) {
            if (turno.getId().equals(id)){
                //ambos id son iguales
                return turno;
            }
        }
        //recorri la lista pero no lo encontre
        return null;
    }

    @Override
    public void actualizar(Turno turno) {
        eliminar(turno.getId());
        guardar(turno);
    }

    @Override
    public void eliminar(Integer id) {
        Turno turnoAEliminar=buscar(id);
        if (turnoAEliminar!=null){
            turnosBD.remove(turnoAEliminar);
        }
    }

    @Override
    public List<Turno> buscarTodo() {
        return turnosBD;
    }

    @Override
    public Turno buscarXString(String valor) {
        return null;
    }
}
