package com.dh.clase23.service;

import com.dh.clase23.dao.IDao;
import com.dh.clase23.dao.PacienteDAOH2;
import com.dh.clase23.dao.TurnoDAOLista;
import com.dh.clase23.model.Paciente;
import com.dh.clase23.model.Turno;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TurnoService {
    private IDao<Turno> turnoDAOLista;

    public TurnoService(){
        turnoDAOLista= new TurnoDAOLista();
    }
    public Turno guardarTurno (Turno turno){
        return turnoDAOLista.guardar(turno);
    }
    public void eliminarTurno(Integer id){
        turnoDAOLista.eliminar(id);
    }
    public void actualizarTurno(Turno turno){
        turnoDAOLista.actualizar(turno);
    }
    public Turno buscarTurno(Integer id){
        return turnoDAOLista.buscar(id);
    }
    public List<Turno> buscarTodosTurno(){
        return turnoDAOLista.buscarTodo();
    }
}
