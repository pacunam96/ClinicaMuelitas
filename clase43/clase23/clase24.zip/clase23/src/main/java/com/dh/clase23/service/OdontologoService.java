package com.dh.clase23.service;

import com.dh.clase23.dao.IDao;
import com.dh.clase23.dao.OdontologoDAOH2;
import com.dh.clase23.model.Odontologo;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class OdontologoService {
    private IDao<Odontologo> odontologoIDao;

    public OdontologoService(){
        odontologoIDao= new OdontologoDAOH2();
    }
    public List<Odontologo> listarOdontologos(){
        return odontologoIDao.buscarTodo();
    }
    public Odontologo guardarOdontologo(Odontologo odontologo){
        return odontologoIDao.guardar(odontologo);
    }
    public void actualizarOdontologo(Odontologo odontologo){
        odontologoIDao.actualizar(odontologo);
    }
    public void eliminarOdontologo(Integer id){
        odontologoIDao.eliminar(id);
    }
    public Odontologo buscarOdontologoXId(Integer id){
        return odontologoIDao.buscar(id);
    }
}
